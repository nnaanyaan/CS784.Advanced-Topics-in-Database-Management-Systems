
import demo_init
import json
try:
    import readline
except:
    pass

db = demo_init.get_db()


if __name__ == "__main__":
    curSql = 'select nested_obj.str, nested_obj.num from argo;'
    for item in db.execute_sql(curSql):
        print json.dumps(item)
        