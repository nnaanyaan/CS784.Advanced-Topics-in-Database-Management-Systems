
import demo_init
import json
from random import randint

try:
    import readline
except:
    pass

db = demo_init.get_db()


if __name__ == "__main__":
    candidate = ["hanging", "why", "down", "rapidly", "corps", "culture", "born"]
    curSql = 'select * from argo where "{}" = any nested_arr;'.format(candidate[randint(0, len(candidate) - 1)])
    for item in db.execute_sql(curSql):
        print json.dumps(item)
        