
import demo_init
import json
from random import randint

try:
    import readline
except:
    pass

db = demo_init.get_db()


if __name__ == "__main__":
    randomnum = str(randint(10, 99))
    curSql = 'select sparse_{}0, sparse_{}9 FROM argo;'.format(randomnum, randomnum)
    for item in db.execute_sql(curSql):
        print json.dumps(item)
        