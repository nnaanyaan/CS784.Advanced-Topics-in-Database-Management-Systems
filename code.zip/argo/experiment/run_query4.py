
import demo_init
import json
from random import randint

try:
    import readline
except:
    pass

db = demo_init.get_db()


if __name__ == "__main__":

    curSql = 'select sparse_{}0, sparse_{}0 FROM argo;'.format(str(randint(10, 99)), str(randint(10, 99)))
    for item in db.execute_sql(curSql):
        print json.dumps(item)
        