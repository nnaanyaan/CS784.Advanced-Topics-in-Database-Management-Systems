

mongoimport --db argo --collection nltk_64m --type json --file nltk_64m --jsonArray

Query 1:
db.nltk_16m.find({}, {"str1":true, "num":true}).explain("executionStats")
Query 2:
db.nltk_16m.find({}, {"nested_obj.str":true, "nested_obj.num":true}).explain("executionStats")
Query 3:
db.nltk_16m.find({ "$or" : [ { "sparse_320" : {"$exists" :true} },
                    { "sparse_229" : {"$exists" :true} } ] },
        {"sparse_320":true, "sparse_229":true}).explain("executionStats")

db.nltk_16m.find({ "$or" : [ { "sparse_210" : {"$exists" :true} },
                    { "sparse_659" : {"$exists" :true} } ] },
        {"sparse_210":true, "sparse_659":true}).explain("executionStats")


        db.nltk_16m.find({ "$or" : [ { "sparse_690" : {"$exists" :true} },
                    { "sparse_869" : {"$exists" :true} } ] },
        {"sparse_690":true, "sparse_869":true}).explain("executionStats")

Query 4:
db.nltk_1m.find(
        { "$or" : [ { "sparse_XX0" : {"$exists" : true} },
                    { "sparse_YY0" : {"$exists" : true} } ] },
        {"sparse_XX0":true, "sparse_YY0":true]).explain("executionStats")

db.nltk_16m.find(
        { "$or" : [ { "sparse_320" : {"$exists" : true} },
                    { "sparse_450" : {"$exists" : true} } ] },
        {"sparse_320":true, "sparse_450":true}).explain("executionStats")

db.nltk_16m.find(
        { "$or" : [ { "sparse_340" : {"$exists" : true} },
                    { "sparse_850" : {"$exists" : true} } ] },
        {"sparse_340":true, "sparse_850":true}).explain("executionStats")

db.nltk_16m.find(
        { "$or" : [ { "sparse_230" : {"$exists" : true} },
                    { "sparse_980" : {"$exists" : true} } ] },
        {"sparse_230":true, "sparse_980":true}).explain("executionStats")

Query 5:
    db.nltk_16m.find({ "str1" : "GBRDCMJQGEYDAMJRGEYA====" }).explain("executionStats")

Query 6:
    db.nltk_16m.find({ "$and": [{ "num" : {"$gte" : 245 } },
                                       { "num" : {"$lt"  : 953 } }]}).explain("executionStats")
Query 7:
    db.nltk_16m.find({ "$and": [{ "dyn1" : {"$gte" : 651 } },
                                       { "dyn1" : {"$lt"  : 897 } }]}).explain("executionStats")

Query 8:
    db.nltk_16m.find({ "nested_arr" : "total" }).explain("executionStats")

Query 9:
    db.nltk_16m.find({ "sparse_678" : "GBRDCMBQGE======" }).explain("executionStats")

Query 10:
    db.nltk_1m.group(
            {"thousandth" : true},
            {"$and": [{"num" : { "$gte" : 100 } },
                    {"num" : { "$lt"  : 300 } }]},
            { "total" : 0 },
            "function(obj, prev) { prev.total += 1; }").explain("executionStats")

    db.nltk_4m.aggregate([ 
    {
        $group : {
           _id : { month: { $month: "$date" }, day: { $dayOfMonth: "$date" }, year: { $year: "$date" } },
           totalPrice: { $sum: { $multiply: [ "$price", "$quantity" ] } },
           averageQuantity: { $avg: "$quantity" },
           count: { $sum: 1 }
        }
    }], allowDiskUse=true).explain("executionStats")
    #  SELECT COUNT(*) FROM nobench_main WHERE num BETWEEN XXXXX AND YYYYY GROUP BY thousandth;
    

Query 11:

    # SELECT * FROM nobench_main AS left
    #                   INNER JOIN nobench_main AS right
    #                   ON (left.nested_obj.str = right.str1)
    #                   WHERE left.num BETWEEN XXXXX AND YYYYY;


    # We build indices on str1 (for Q5), num (for Q6 and Q10), dyn1 (for Q7),
    #  and nested arr (for Q8). We do not build indices on any sparse attributes 
    # (which might help Q9, and possibly Q3 and Q4), as that would require 
    # the creation of 1000 separate indices to support any possible 
    # parameterization of the queries.

    db.nltk_16m.createIndex({str1:1})
    db.nltk_16m.createIndex({num:1}).explain("executionStats")
    db.nltk_16m.createIndex({dyn1:1})
    db.nltk_16m.createIndex({nested_arr:1})
