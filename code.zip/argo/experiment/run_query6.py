
import demo_init
import json
from random import randint

try:
    import readline
except:
    pass

db = demo_init.get_db()


if __name__ == "__main__":
    lowerbound = randint(100, 999)
    upperbound = randint(lowerbound, 999)
    curSql = 'select * from argo where num>{} and num<{};'.format(str(lowerbound), str(upperbound))
    for item in db.execute_sql(curSql):
        print json.dumps(item)
        