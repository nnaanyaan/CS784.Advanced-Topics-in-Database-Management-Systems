

for i in range(1, 10):
    echo "Q1" >> nltk_1m.txt
    time python run_query1.py >> nltk_1m.txt
    echo "Q2" >> nltk_1m.txt
    time python run_query2.py >> nltk_1m.txt
    echo "Q3" >> nltk_1m.txt
    time python run_query3.py >> nltk_1m.txt
    echo "Q4" >> nltk_1m.txt
    time python run_query4.py >> nltk_1m.txt
    echo "Q5" >> nltk_1m.txt
    time python run_query5.py >> nltk_1m.txt
    echo "Q6" >> nltk_1m.txt
    time python run_query6.py >> nltk_1m.txt
    echo "Q7" >> nltk_1m.txt
    time python run_query7.py >> nltk_1m.txt
    echo "Q8" >> nltk_1m.txt
    time python run_query8.py >> nltk_1m.txt
    echo "Q9" >> nltk_1m.txt
    time python run_query9.py >> nltk_1m.txt
