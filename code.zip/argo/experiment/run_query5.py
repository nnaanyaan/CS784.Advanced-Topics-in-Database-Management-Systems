    
import demo_init
import json
from random import randint

try:
    import readline
except:
    pass

db = demo_init.get_db()


if __name__ == "__main__":
    candidate = ["GBRDCMJQGEYTAMBQGEYQ====", "GBRDCMBRGEYA====", "GBRDCMJQGEYDCMBQ", "GBRDCMBQGEYTC===", "GBRDCMJQGEYDCMJQ"]
    curSql = 'select * from argo where str1 = "{}";'.format(candidate[randint(0, len(candidate) - 1)])
    for item in db.execute_sql(curSql):
        print json.dumps(item)
        