
import demo_init
import json
from random import randint

try:
    import readline
except:
    pass

db = demo_init.get_db()


if __name__ == "__main__":
    candidate = ["GBRDCMJR", "GBRDCMA=", "GBRDCMJQ", "GBRDCMJQ", "GBRDCMI=", "GBRDCMBQGE======"]
    curSql = 'select * from argo where sparse_{} = "{}";'.format(str(randint(100, 999)), candidate[randint(0, len(candidate) - 1)])
    for item in db.execute_sql(curSql):
        print json.dumps(item)
        