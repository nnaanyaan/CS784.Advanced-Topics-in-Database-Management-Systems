
from ..demo_init import demo_init
import json
try:
    import readline
except:
    pass

db = demo_init.get_db()


if __name__ == "__main__":
    curSql = 'select str1, num from argo;'
    for item in db.execute_sql(curSql):
        print json.dumps(item)
        