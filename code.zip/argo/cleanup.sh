#!/bin/bash

rm -f *.pyc
rm -f *~
rm -f parsetab.py
rm -f parser.out
