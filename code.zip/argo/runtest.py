import psycopg2
import dbms_postgres
import argodb
import demo_init
import json
try:
    import readline
except:
    pass
USE_ARGO_1 = False

# Set to false to use Argo/3, true to use Argo/1.

if __name__ == "__main__":
    conn = psycopg2.connect("user=whw password='whw' dbname=argo")
    dbms = dbms_postgres.PostgresDBMS(conn)
    db = argodb.ArgoDB(dbms, USE_ARGO_1)
    with open("../dataset/nltk_1m", "rb") as infile:
        for line in infile.readlines():
            # print(line.rstrip('\n').rstrip(','))
            try: 
                cursor = conn.cursor()
                cursor.execute("start transaction")
                db.execute_sql(line)
            except Exception, e:
                print "ERROR: " + str(e)
        
        cursor.execute("commit")
        cursor.close()
        conn.commit()